angular.module('beamng.apps').directive('trafficTuner', ['$timeout', '$interval', function ($timeout, $interval) {
  return {
    template: `
      <div class="tt-wrap" ng-class="{'tt-minimized': minimized}">
        <style>
          .tt-wrap{box-sizing:border-box;width:100%;height:100%;overflow:auto;padding:16px;background:linear-gradient(155deg,#171c27,#10141c);color:#edf2fa;font:13px/1.4 "Segoe UI",Arial,sans-serif;border:1px solid #ffffff16;border-radius:12px;box-shadow:0 10px 30px #0006}
          .tt-head{display:flex;align-items:center;gap:11px;margin-bottom:12px;position:relative;padding-right:48px}.tt-mark{width:36px;height:36px;display:grid;place-items:center;border-radius:10px;background:#f07837;color:#17141a;font-weight:900;font-size:20px}.tt-title{font-weight:750;font-size:16px;letter-spacing:.2px}.tt-sub{font-size:10px;color:#aab4c5;margin-top:2px}
          .tt-head button{position:absolute;right:0;top:2px;background:#ffffff12;color:#edf2fa;border:1px solid #ffffff25;border-radius:6px;padding:5px 8px;font-size:11px}
          .tt-live{display:flex;align-items:center;gap:7px;font-size:11px;color:#aab4c5;margin-bottom:12px;padding:6px 9px;background:#ffffff08;border-radius:7px}.tt-dot{width:8px;height:8px;border-radius:50%;background:#7a8599}.tt-dot.on{background:#5ed486}.tt-dot.warn{background:#f0b437}
          .tt-presets{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin-bottom:12px}.tt-presets button{background:#ffffff0d;border:1px solid #ffffff17;color:#dce4ef;border-radius:7px;padding:7px 2px;font-size:11px}.tt-presets button:hover{background:#f078372b;border-color:#f07837}
          .tt-label{display:flex;justify-content:space-between;font-weight:650;margin:12px 0 5px}.tt-label span{color:#f49a68;font-variant-numeric:tabular-nums}input[type=range]{width:100%;accent-color:#f07837;margin:3px 0}.tt-scale{display:flex;justify-content:space-between;color:#8994a6;font-size:10px;margin-top:-2px}
          .tt-select{width:100%;display:flex;justify-content:space-between;align-items:center;text-align:left;padding:9px 10px;color:#edf2fa;background:#202735;border:1px solid #ffffff1c;border-radius:7px}.tt-menu{margin-top:4px;padding:4px;background:#202735;border:1px solid #ffffff1c;border-radius:7px}.tt-menu button{display:block;width:100%;text-align:left;padding:8px;color:#edf2fa;background:transparent;border:0;border-radius:5px}.tt-menu button:hover,.tt-menu button.tt-selected{background:#f0783733;color:#fff}
          .tt-toggle{display:flex;align-items:center;gap:8px;margin:11px 0;color:#d9e1ed}.tt-toggle input{accent-color:#f07837;width:15px;height:15px}.tt-section{color:#f49a68;font-size:11px;font-weight:750;letter-spacing:.5px;text-transform:uppercase;margin-top:15px}
          .tt-row{display:flex;gap:6px;margin-top:12px}.tt-apply{flex:1;padding:10px;border:0;border-radius:8px;background:#f07837;color:#17141a;font-weight:750;letter-spacing:.2px}.tt-apply:hover{background:#ff9250}.tt-reset{padding:10px 12px;border:1px solid #ffffff25;border-radius:8px;background:#ffffff0d;color:#dce4ef}
          .tt-note{font-size:10px;color:#aab4c5;line-height:1.5;margin-top:11px}.tt-status{font-size:11px;color:#ffb39c;margin-top:8px;min-height:15px}.tt-ok{color:#9de0b2}
          .tt-minimized{height:48px!important;min-height:48px!important;overflow:hidden!important;padding:6px 10px!important}.tt-minimized .tt-head{margin:0}.tt-minimized .tt-mark{width:32px;height:32px}.tt-minimized .tt-head button{top:4px}
        </style>
        <header class="tt-head">
          <div class="tt-mark">T</div>
          <div><div class="tt-title">Traffic Tuner</div><div class="tt-sub">AI behavior · density · performance</div></div>
          <button ng-click="toggleMinimized()">{{minimized ? 'Show' : 'Hide'}}</button>
        </header>
        <div class="tt-content" ng-hide="minimized">
          <div class="tt-live"><span class="tt-dot" ng-class="live.cls"></span><span>{{live.text}}</span></div>

          <div class="tt-presets">
            <button ng-click="preset('calm')">Calm</button>
            <button ng-click="preset('natural')">Natural</button>
            <button ng-click="preset('lively')">Lively</button>
            <button ng-click="preset('smooth')">Smooth</button>
          </div>

          <label class="tt-label">AI risk / aggression <span>{{settings.aggression | number:2}}</span></label>
          <input type="range" min="0.25" max="1.25" step="0.05" ng-model="settings.aggression" ng-change="queueApply()">
          <div class="tt-scale"><span>Careful</span><span>Very aggressive</span></div>

          <label class="tt-label">Speed cap <span>{{speedText()}}</span></label>
          <input type="range" min="40" max="300" step="10" ng-model="settings.speedKph" ng-change="queueApply()">
          <div class="tt-scale"><span>40 km/h</span><span>No cap</span></div>

          <label class="tt-label">Active traffic cars <span>{{settings.active}}</span></label>
          <input type="range" min="2" max="24" step="1" ng-model="settings.active" ng-change="queueApply()">
          <div class="tt-scale"><span>Faster</span><span>Busier</span></div>

          <label class="tt-label">Vehicle awareness</label>
          <button class="tt-select" ng-click="awarenessOpen = !awarenessOpen">
            <span>{{awarenessLabel()}}</span><span>{{awarenessOpen ? '▲' : '▼'}}</span>
          </button>
          <div class="tt-menu" ng-show="awarenessOpen">
            <button ng-class="{'tt-selected': settings.awareness === 'auto'}" ng-click="chooseAwareness('auto')">Automatic (recommended)</button>
            <button ng-class="{'tt-selected': settings.awareness === 'on'}" ng-click="chooseAwareness('on')">More aware of other vehicles</button>
            <button ng-class="{'tt-selected': settings.awareness === 'off'}" ng-click="chooseAwareness('off')">Less awareness</button>
          </div>

          <div class="tt-section">Traffic interactions</div>
          <label class="tt-toggle"><input type="checkbox" ng-model="settings.overtaking" ng-change="queueApply()"><span>Enable safer overtake planning</span></label>
          <label class="tt-toggle"><input type="checkbox" ng-model="settings.flashOvertakes" ng-change="queueApply()"><span>Flash twice when closing to pass</span></label>
          <label class="tt-toggle"><input type="checkbox" ng-model="settings.smoothYield" ng-change="queueApply()"><span>Yield earlier to emergency lights</span></label>
          <label class="tt-label">Road-rage driver share <span>{{settings.roadRageShare}}%</span></label>
          <input type="range" min="0" max="50" step="5" ng-model="settings.roadRageShare" ng-change="queueApply()">
          <div class="tt-scale"><span>None</span><span>More frequent</span></div>

          <label class="tt-toggle"><input type="checkbox" ng-model="settings.events" ng-change="queueApply()"><span>Allow occasional AI events</span></label>
          <div class="tt-row">
            <button class="tt-apply" ng-click="apply()">Apply to traffic</button>
            <button class="tt-reset" ng-click="preset('natural')" title="Back to the Natural preset">Reset</button>
          </div>
          <div class="tt-note">Changes apply automatically a moment after you adjust a control, and are remembered next time. Road-rage share only affects cars spawned after applying. BeamNG's own planner still handles turns, obstacles and passing safety; at the top of the speed slider the cap is removed.</div>
          <div class="tt-status" ng-class="{'tt-ok': applied}">{{status}}</div>
        </div>
      </div>`,
    replace: true,
    restrict: 'EA',
    link: function (scope) {
      var STORE_KEY = 'trafficTunerSettings.v1';
      var NO_CAP_KPH = 300;
      var defaults = { aggression: 0.6, speedKph: 160, active: 8, awareness: 'auto', events: false, overtaking: true, flashOvertakes: true, smoothYield: true, roadRageShare: 15 };
      var presets = {
        calm:    { aggression: 0.30, speedKph: 100, active: 6,  awareness: 'on',   events: false, overtaking: true, flashOvertakes: false, smoothYield: true, roadRageShare: 0 },
        natural: angular.copy(defaults),
        lively:  { aggression: 1.00, speedKph: 240, active: 10, awareness: 'auto', events: true,  overtaking: true, flashOvertakes: true,  smoothYield: true, roadRageShare: 30 },
        smooth:  { aggression: 0.40, speedKph: 120, active: 5,  awareness: 'on',   events: false, overtaking: true, flashOvertakes: false, smoothYield: true, roadRageShare: 5 }
      };

      function loadSaved() {
        try {
          var raw = window.localStorage.getItem(STORE_KEY);
          if (raw) return angular.extend(angular.copy(defaults), JSON.parse(raw));
        } catch (e) {}
        return angular.copy(defaults);
      }
      function save() { try { window.localStorage.setItem(STORE_KEY, JSON.stringify(scope.settings)); } catch (e) {} }

      scope.settings = loadSaved();
      scope.status = 'Adjust a control or pick a preset.';
      scope.applied = false;
      scope.minimized = false;
      scope.awarenessOpen = false;
      scope.live = { cls: '', text: 'Checking traffic...' };

      scope.toggleMinimized = function () { scope.minimized = !scope.minimized; };
      scope.awarenessLabel = function () {
        var labels = { auto: 'Automatic (recommended)', on: 'More aware of other vehicles', off: 'Less awareness' };
        return labels[scope.settings.awareness] || labels.auto;
      };
      scope.chooseAwareness = function (value) {
        scope.settings.awareness = value;
        scope.awarenessOpen = false;
        scope.queueApply();
      };
      scope.speedText = function () {
        var v = Number(scope.settings.speedKph);
        return v >= NO_CAP_KPH ? 'No cap' : v + ' km/h';
      };
      scope.preset = function (name) {
        scope.settings = angular.copy(presets[name] || presets.natural);
        scope.apply();
      };

      // Build the Lua call. Everything is wrapped so a missing function can't break the rest.
      function buildLua(s) {
        var aggression = Math.max(0.25, Math.min(1.25, Number(s.aggression) || 0.6));
        var noCap = Number(s.speedKph) >= NO_CAP_KPH;
        var speedMs = Math.max(1, (Number(s.speedKph) || 160) / 3.6);
        var active = Math.max(1, Math.min(24, Math.round(Number(s.active) || 8)));
        var awareness = ['auto', 'on', 'off'].indexOf(s.awareness) >= 0 ? s.awareness : 'auto';
        var rage = Math.max(0, Math.min(50, Number(s.roadRageShare) || 0));
        var bool = function (v) { return v ? 'true' : 'false'; };

        var trafficVars = 'baseAggression=' + aggression.toFixed(2) +
          (noCap ? '' : ',speedLimit=' + speedMs.toFixed(2)) +
          ',activeAmount=' + active + ",aiAware='" + awareness + "',enableRandomEvents=" + bool(s.events);
        var tuner = 'baseAggression=' + aggression.toFixed(2) + ',speedLimit=' + speedMs.toFixed(2) +
          ',noSpeedCap=' + bool(noCap) + ",aiAware='" + awareness + "',overtaking=" + bool(s.overtaking) +
          ',flashOvertakes=' + bool(s.flashOvertakes) + ',smoothYield=' + bool(s.smoothYield) + ',roadRageShare=' + rage;

        return "extensions.load('gameplay_traffic'); extensions.load('trafficTuner_behavior'); " +
          "pcall(function() gameplay_traffic.setTrafficVars({" + trafficVars + "}) end); " +
          "if trafficTuner_behavior then trafficTuner_behavior.apply({" + tuner + "}) end";
      }

      var pending = null;
      scope.queueApply = function () {
        scope.applied = false;
        scope.status = 'Applying...';
        if (pending) $timeout.cancel(pending);
        pending = $timeout(function () { pending = null; scope.apply(); }, 350);
      };

      scope.apply = function () {
        if (pending) { $timeout.cancel(pending); pending = null; }
        save();
        bngApi.engineLua(buildLua(scope.settings));
        scope.applied = true;
        scope.status = 'Settings sent to BeamNG traffic.';
        $timeout(scope.refreshLive, 400);
      };

      // Live status: shows whether traffic is running so "nothing happens" is explained.
      scope.refreshLive = function () {
        bngApi.engineLua("trafficTuner_behavior and trafficTuner_behavior.getStatus() or 'noext'", function (res) {
          scope.$evalAsync(function () {
            if (typeof res !== 'string' || res === 'noext') {
              scope.live = { cls: 'warn', text: 'Tuner not loaded yet - press Apply.' };
              return;
            }
            var p = res.split('|');
            var cars = Number(p[0]) || 0, incidents = Number(p[1]) || 0;
            if (cars === 0) scope.live = { cls: 'warn', text: 'No AI traffic running - start traffic first.' };
            else scope.live = { cls: 'on', text: cars + ' traffic car' + (cars === 1 ? '' : 's') + ' tuned' + (incidents ? ' · ' + incidents + ' incident' + (incidents === 1 ? '' : 's') : '') };
          });
        });
      };

      // Load the extension and re-apply remembered settings when the app opens.
      $timeout(function () { scope.apply(); scope.status = 'Loaded your last settings.'; }, 500);
      var poll = $interval(scope.refreshLive, 2500);
      scope.$on('$destroy', function () { $interval.cancel(poll); if (pending) $timeout.cancel(pending); });
    }
  };
}]);
