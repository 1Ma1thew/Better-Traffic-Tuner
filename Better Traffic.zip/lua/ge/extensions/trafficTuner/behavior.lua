-- BeamNG Traffic Tuner: behaviour helpers (loaded as extension "trafficTuner_behavior").
-- File location matters: BeamNG maps extension "a_b" to lua/ge/extensions/a/b.lua.
-- Every game-facing call is wrapped in pcall so one API difference between game
-- versions can never spam errors or stop the rest of the mod from working.
local M = {}
M.dependencies = {'gameplay_traffic'}

local logTag = 'trafficTuner'
local options = {
  overtaking = true,
  flashOvertakes = true,
  smoothYield = true,
  roadRageShare = 15,
  baseAggression = 0.6,
  speedLimit = 44.44,   -- m/s
  noSpeedCap = false,
  aiAware = 'auto'
}

local tick, clock = 0, 0
local flashCooldown, flashPulses, rageAssigned, yielding = {}, {}, {}, {}
local incidentCars, incidentCooldown, incidentChasing = {}, {}, {}
local incidentCheck = 0
local appliedCount = 0
local errorSeen = {}

local function clampNum(v, lo, hi) return math.max(lo, math.min(hi, v)) end

-- Run fn safely; log each distinct error only once.
local function try(label, fn, ...)
  local ok, err = pcall(fn, ...)
  if not ok and not errorSeen[label] then
    errorSeen[label] = true
    log('W', logTag, 'Recovered from error in ' .. label .. ': ' .. tostring(err))
  end
  return ok
end

local function getTraffic()
  if gameplay_traffic and gameplay_traffic.getTrafficData then
    return gameplay_traffic.getTrafficData() or {}
  end
  return {}
end

local function trafficCount()
  local n = 0
  for _ in pairs(getTraffic()) do n = n + 1 end
  return n
end

local function queueVehicle(id, command)
  local obj = be and be:getObjectByID(id)
  if obj then obj:queueLuaCommand(command) end
end

local function isEmergencyRole(veh)
  local r = veh and veh.roleName
  return r == 'police' or r == 'emergency'
end

local function applyDriverProfile(id, veh)
  if rageAssigned[id] or not veh or not veh.isAi or veh.roleName ~= 'standard' then return end
  rageAssigned[id] = true
  local role = veh.role
  local personality = role and role.driver and role.driver.personality
  local share = clampNum(tonumber(options.roadRageShare) or 0, 0, 50) / 100
  if not personality or math.random() >= share then return end

  role.personalityModifiers = role.personalityModifiers or {}
  role.personalityModifiers.bravery = {min = 0.62, max = 0.80}
  role.personalityModifiers.aggression = {min = 0.65, max = 0.85}
  personality.bravery = math.max(personality.bravery or 0.5, 0.62 + math.random() * 0.18)
  personality.aggression = math.max(personality.aggression or 0.5, 0.65 + math.random() * 0.2)
  if role.onRefresh then role:onRefresh() end
  if role.setAggression then role:setAggression() end
end

-- Aggression for one car: keep a little per-driver variety so traffic does not look cloned.
local function aggressionFor(veh)
  local base = options.baseAggression
  local p = veh and veh.role and veh.role.driver and veh.role.driver.personality
  if p and p.aggression then base = base * (0.85 + 0.3 * clampNum(p.aggression, 0, 1)) end
  return clampNum(base, 0.25, 1.25)
end

local function applyVehicle(id, veh)
  if not veh or not veh.isAi then return end
  if not isEmergencyRole(veh) then
    local cmds = {}
    cmds[#cmds + 1] = string.format('ai.setAggression(%.3f)', aggressionFor(veh))
    if options.noSpeedCap then
      cmds[#cmds + 1] = "ai.setSpeedMode('off')"
    else
      cmds[#cmds + 1] = "ai.setSpeedMode('limit')"
      cmds[#cmds + 1] = string.format('ai.setSpeed(%.2f)', options.speedLimit)
    end
    if options.aiAware == 'on' then cmds[#cmds + 1] = "ai.setAvoidCars('on')"
    elseif options.aiAware == 'off' then cmds[#cmds + 1] = "ai.setAvoidCars('off')" end
    queueVehicle(id, table.concat(cmds, '; '))
  end
  -- ai.setRacing may not exist in every game version, so guard it on the vehicle side.
  queueVehicle(id, 'if ai.setRacing then ai.setRacing(' .. (options.overtaking and 'true' or 'false') .. ') end')
  applyDriverProfile(id, veh)
end

local function clearIncident(id)
  if not incidentCars[id] then return end
  queueVehicle(id, 'electrics.set_warn_signal(0)')
  queueVehicle(id, 'electrics.set_lightbar_signal(0)')
  local veh = getTraffic()[id]
  if veh and veh.role and veh.role.flags and veh.role.flags.trafficTunerIncident then
    veh.role.flags.trafficTunerIncident = nil
    if veh.role.resetAction then veh.role:resetAction() end
    applyVehicle(id, veh)
  end
  incidentCars[id] = nil
end

local function updateCrashIncidents(traffic, dt)
  incidentCheck = incidentCheck + dt
  if incidentCheck < 0.5 then return end
  local step = incidentCheck
  incidentCheck = 0
  local participating = {}

  for id, veh in pairs(traffic) do
    if veh.isAi and veh.collisions then
      for otherId, collision in pairs(veh.collisions) do
        if collision.state == 'active' and (collision.count or 0) >= 1 then
          participating[id], participating[otherId] = true, true
          local target, role = traffic[otherId], veh.role
          if target and role and role.driver and role.driver.eventType == 'selfCollision'
              and target.speed and target.speed > (veh.speed or 0) + 3
              and (veh.roleName ~= 'standard' or (role.driver.personality and (role.driver.personality.bravery or 0) >= 0.56))
              and not (role.flags and role.flags.trafficTunerChasing) then
            role.flags = role.flags or {}
            role.flags.trafficTunerChasing = true
            incidentChasing[id] = true
            if role.setTarget then role:setTarget(otherId) end
            if role.setAction then
              role:setAction('followPostCrash', {reason = 'selfCollision', targetId = otherId, isChase = true, aggression = 1.0})
            end
          end
        end
      end
    end
  end

  for id in pairs(participating) do
    if not incidentCars[id] and (not incidentCooldown[id] or incidentCooldown[id] <= clock) then
      local veh = traffic[id]
      if veh then
        incidentCars[id] = {time = 0, otherIds = participating}
        incidentCooldown[id] = clock + 120
        queueVehicle(id, 'electrics.set_warn_signal(1)')
        if veh.isAi and not incidentChasing[id] and veh.role and veh.role.setAction then
          local dist = 20
          if veh.getBrakingDistance then dist = math.max(8, veh:getBrakingDistance(veh.speed or 0, 0.5)) end
          veh.role:setAction('pullOver', {dist = dist, reason = 'trafficTunerIncident', useWarnSignal = true})
          veh.role.flags = veh.role.flags or {}
          veh.role.flags.trafficTunerIncident = true
        end
      end
    end
  end
  incidentChasing = {}

  for id, incident in pairs(incidentCars) do
    incident.time = incident.time + step
    local someoneLeaving = false
    for otherId in pairs(incident.otherIds or {}) do
      local other = traffic[otherId]
      if other and otherId ~= id and other.speed and other.speed > 8 then someoneLeaving = true end
    end
    if incident.time >= 120 or someoneLeaving then clearIncident(id) end
  end
end

-- Headlight flash; falls back safely if this game version has no such function.
local FLASH_ON  = 'if electrics.light_flash_highbeams then electrics.light_flash_highbeams(true) end'
local FLASH_OFF = 'if electrics.light_flash_highbeams then electrics.light_flash_highbeams(false) end'

local function beginFlash(id)
  if flashPulses[id] then return end
  queueVehicle(id, FLASH_ON)
  flashPulses[id] = {time = 0, on = true, count = 0}
end

local function updateFlashes(dt)
  for id, pulse in pairs(flashPulses) do
    pulse.time = pulse.time + dt
    if pulse.time >= (pulse.on and 0.14 or 0.10) then
      pulse.time = 0
      if pulse.on then
        queueVehicle(id, FLASH_OFF)
        pulse.on = false
        pulse.count = pulse.count + 1
        if pulse.count >= 2 then flashPulses[id] = nil end
      else
        queueVehicle(id, FLASH_ON)
        pulse.on = true
      end
    end
  end
end

-- Multi-lane check. Uses lane info when the game exposes it; otherwise assumes passing is possible
-- (BeamNG's own planner still decides whether an overtake actually happens).
local function hasPassingRoom(veh)
  local lanes = veh.tracking and veh.tracking.linkData and veh.tracking.linkData.lanes
  if type(lanes) ~= 'string' then return true end
  local _, count = string.gsub(lanes, '[%+%-]', '')
  return count >= 2
end

local function findSlowerTrafficAhead(follower, allTraffic)
  if not follower.driveVec or not follower.pos or not hasPassingRoom(follower) then return nil end
  local right = vec3(follower.driveVec.y, -follower.driveVec.x, 0)
  if right:squaredLength() < 1e-6 then return nil end
  right:normalize()

  local closest, closestGap
  for otherId, leader in pairs(allTraffic) do
    if otherId ~= follower.id and leader.pos and leader.driveVec then
      if follower.driveVec:dot(leader.driveVec) > 0.95 then
        local delta = leader.pos - follower.pos
        local gap = delta:dot(follower.driveVec)
        local lateral = math.abs(delta:dot(right))
        local closing = (follower.speed or 0) - (leader.speed or 0)
        local safeGap = math.max(8, ((follower.length or 4) + (leader.length or 4)) * 0.5 + 3)
        if gap > safeGap and gap < 40 and lateral < 3.5 and closing > 2.5 and (not closestGap or gap < closestGap) then
          closest, closestGap = leader, gap
        end
      end
    end
  end
  return closest
end

local function findEmergencyVehicles()
  local found = {}
  if not (map and map.objects) then return found end
  for id, obj in pairs(map.objects) do
    local states = obj.states
    if states and (states.lightbar == 2 or (states.lightbar == 1 and obj.vel and obj.vel:squaredLength() >= 100)) then
      found[#found + 1] = {id = id, pos = obj.pos}
    end
  end
  return found
end

local function updateEmergencyYield(traffic, emergencyVehicles)
  for id, veh in pairs(traffic) do
    if veh.isAi and veh.pos and not isEmergencyRole(veh) then
      local emergencyNear = false
      if options.smoothYield then
        for _, emergency in ipairs(emergencyVehicles) do
          if emergency.id ~= id and emergency.pos and veh.pos:squaredDistance(emergency.pos) <= 10000 then
            emergencyNear = true
            break
          end
        end
      end
      if emergencyNear and not yielding[id] then
        queueVehicle(id, string.format('ai.setAggression(%.3f)', math.min(aggressionFor(veh), 0.55)))
        yielding[id] = true
      elseif not emergencyNear and yielding[id] then
        queueVehicle(id, string.format('ai.setAggression(%.3f)', aggressionFor(veh)))
        yielding[id] = nil
      end
    end
  end
end

local function applyAll()
  local n = 0
  for id, veh in pairs(getTraffic()) do
    try('applyVehicle', applyVehicle, id, veh)
    n = n + 1
  end
  appliedCount = n
  return n
end

function M.apply(data)
  data = data or {}
  options.overtaking = data.overtaking ~= false
  options.flashOvertakes = data.flashOvertakes ~= false
  options.smoothYield = data.smoothYield ~= false
  options.noSpeedCap = data.noSpeedCap == true
  options.roadRageShare = clampNum(tonumber(data.roadRageShare) or options.roadRageShare, 0, 50)
  options.baseAggression = clampNum(tonumber(data.baseAggression) or options.baseAggression, 0.25, 1.25)
  options.speedLimit = clampNum(tonumber(data.speedLimit) or options.speedLimit, 11.11, 83.33)
  options.aiAware = (data.aiAware == 'on' or data.aiAware == 'off') and data.aiAware or 'auto'
  local n = applyAll()
  log('I', logTag, string.format('Applied: aggression=%.2f cap=%s awareness=%s -> %d traffic cars',
    options.baseAggression, options.noSpeedCap and 'none' or string.format('%.0f km/h', options.speedLimit * 3.6), options.aiAware, n))
  return n
end

-- Polled by the UI: "<traffic cars>|<incidents>". Always returns a string.
function M.getStatus()
  local active = 0
  for _, veh in pairs(getTraffic()) do if veh.isAi then active = active + 1 end end
  local incidents = 0
  for _ in pairs(incidentCars) do incidents = incidents + 1 end
  return string.format('%d|%d', active, incidents)
end

function M.onExtensionLoaded()
  log('I', logTag, 'Traffic Tuner extension loaded')
end

function M.onTrafficVehicleAdded(id)
  try('onTrafficVehicleAdded', function() applyVehicle(id, getTraffic()[id]) end)
end

function M.onTrafficVehicleRemoved(id)
  flashCooldown[id], rageAssigned[id], yielding[id] = nil, nil, nil
  flashPulses[id], incidentCars[id], incidentCooldown[id] = nil, nil, nil
end

function M.onVehicleResetted(id)
  try('onVehicleResetted', function()
    local veh = getTraffic()[id]
    if veh then applyVehicle(id, veh) end
  end)
end

function M.onTrafficStarted()
  try('onTrafficStarted', applyAll)
end

function M.onUpdate(dtReal, dtSim)
  local dt = dtSim or dtReal or 0
  clock = clock + dt
  try('updateFlashes', updateFlashes, dt)
  tick = tick + dt
  if tick < 0.35 then return end
  tick = 0

  local traffic = getTraffic()
  try('updateCrashIncidents', updateCrashIncidents, traffic, dt)
  if options.smoothYield then
    try('updateEmergencyYield', function() updateEmergencyYield(traffic, findEmergencyVehicles()) end)
  end

  if options.overtaking and options.flashOvertakes then
    try('overtakeFlash', function()
      for id, veh in pairs(traffic) do
        if veh.isAi and veh.state == 'active' and (not flashCooldown[id] or flashCooldown[id] <= clock) then
          if findSlowerTrafficAhead(veh, traffic) then
            beginFlash(id)
            flashCooldown[id] = clock + 12 + math.random() * 8
          end
        end
      end
    end)
  end
end

return M
