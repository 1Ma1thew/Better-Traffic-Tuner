# BeamNG Traffic Tuner 1.8

A BeamNG UI app for tuning current AI traffic.

## Install
1. Copy `BeamNG_Traffic_Tuner.zip` into your BeamNG.drive user folder's `mods` directory (Documents/BeamNG.drive/<version>/mods). Leave it zipped.
2. Start the game, open Freeroam, enter UI Edit mode, choose **Add App** and add **Traffic Tuner**.
3. Start traffic, then pick a preset or move a slider. Changes apply automatically and are remembered.

## What changed in 1.8
- FIX: the Lua file was in the wrong place (lua/ge/extensions/trafficTuner_behavior.lua). BeamNG maps extension
  "trafficTuner_behavior" to lua/ge/extensions/trafficTuner/behavior.lua, so the behaviour code never loaded.
- FIX: all game calls are error-guarded and logged once to beamng.log (search for "trafficTuner").
- FIX: overtake flash no longer requires lane data the game may not expose; headlight flash and AI calls are
  guarded so they fail quietly on game versions that lack them.
- NEW: live status line (traffic running? how many cars tuned? incidents).
- NEW: auto-apply shortly after any change, settings remembered, Reset button, speed slider's top end = No cap.
- CHANGED: speed cap is no longer silently removed at max aggression; use the slider's "No cap" end instead.
- CHANGED: aggression keeps a little per-driver variety; police/emergency roles are left alone.

## Troubleshooting
Check the status line in the app. If it says "Tuner not loaded", press Apply. If it says no traffic, start traffic.
If it still misbehaves, send the lines containing "trafficTuner" from BeamNG's beamng.log.
